UPDATE `version` SET `db_version`=('Cataclysm DB & "patch" SmartAI Lab 434.01');

