OPTIMIZE TABLE custom_texts;
OPTIMIZE TABLE script_localized_texts;
OPTIMIZE TABLE script_texts;
OPTIMIZE TABLE script_waypoint;
OPTIMIZE TABLE sd2_db_version;