WARNING! BETA RELEASE! Don't use it on production!

This port based on http://info.iet.unipi.it/~luigi/dummynet

////////////////////////////////////////////////////////////////
Supported actions:
log, allow, drop, count, skipto, check-states, queue, pipe

Not supported actions:
unreach, reset, reject, divert, tee, fwd

Not supported options currently:
"recv, xmit, via" with adapter name.

///////////////////////////////////////////////////////////////
INSTALL

 Enter to Control Panel -> Network and select one card

- click on Properties->Install->Service->Add
- click on 'Driver Disk' and select 'netipfw.inf' in this folder
- select 'ipfw+dummynet' which is the only service you should see
- click accept on the warnings for the installation of an unknown
  driver (roughly twice per existing network card)

- start 'install_svc.cmd' script

**

UNINSTALL

- select a network card as above.
- click on Properties
- select 'ipfw+dummynet'
- click on 'Remove'

- start 'uninstall_svc.cmd' script
